<?php
/*
Plugin Name: Image Sections Plugin
Plugin URI: https://example.com
Description: A plugin to add image sections with titles, links, and custom text displayed in a responsive grid using a shortcode.
Version: 1.0
Author: Rahul K R
Author URI: https://example.com
License: GPL2
*/

// Register Custom Post Type
function isp_register_image_section_cpt() {
    register_post_type('image_section', array(
        'labels' => array(
            'name' => 'Image Sections',
            'singular_name' => 'Image Section',
            'add_new' => 'Add New Section',
            'add_new_item' => 'Add New Image Section',
            'edit_item' => 'Edit Image Section',
            'new_item' => 'New Image Section',
            'view_item' => 'View Image Section',
            'search_items' => 'Search Image Sections',
            'not_found' => 'No sections found',
        ),
        'public' => true,
        'has_archive' => true,
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-format-gallery',
    ));
}
add_action('init', 'isp_register_image_section_cpt');

// Add Meta Boxes for Link and Custom Text
function isp_add_meta_boxes() {
    add_meta_box(
        'isp_meta_box',
        'Image Section Details',
        'isp_meta_box_callback',
        'image_section',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'isp_add_meta_boxes');

function isp_meta_box_callback($post) {
    $link = get_post_meta($post->ID, '_isp_link', true);
    $custom_text = get_post_meta($post->ID, '_isp_custom_text', true);
    ?>
    <p>
        <label for="isp_link">External Link:</label>
        <input type="url" id="isp_link" name="isp_link" value="<?php echo esc_url($link); ?>" style="width: 100%;">
    </p>
    <p>
        <label for="isp_custom_text">Custom Text:</label>
        <textarea id="isp_custom_text" name="isp_custom_text" rows="4" style="width: 100%;"><?php echo esc_textarea($custom_text); ?></textarea>
    </p>
    <?php
}

function isp_save_meta_boxes($post_id) {
    if (array_key_exists('isp_link', $_POST)) {
        update_post_meta($post_id, '_isp_link', esc_url_raw($_POST['isp_link']));
    }
    if (array_key_exists('isp_custom_text', $_POST)) {
        update_post_meta($post_id, '_isp_custom_text', sanitize_textarea_field($_POST['isp_custom_text']));
    }
}
add_action('save_post', 'isp_save_meta_boxes');

// Shortcode to Display Image Sections
function isp_display_image_sections() {
    $query = new WP_Query(array(
        'post_type' => 'image_section',
        'posts_per_page' => -1,
    ));

    if ($query->have_posts()) {
        $output = '<div class="isp-container">';
        while ($query->have_posts()) {
            $query->the_post();
            $link = get_post_meta(get_the_ID(), '_isp_link', true);
            $custom_text = get_post_meta(get_the_ID(), '_isp_custom_text', true);
            $thumbnail = get_the_post_thumbnail(get_the_ID(), 'medium', array('style' => 'width: 100%; height: auto;'));
            
            $output .= '<div class="isp-item">';
            $output .= $link ? '<a href="' . esc_url($link) . '" target="_blank">' . $thumbnail . '</a>' : $thumbnail;
            $output .= '<h3>' . get_the_title() . '</h3>';
            $output .= '<p>' . esc_html($custom_text) . '</p>';
            $output .= '</div>';
        }
        wp_reset_postdata();
        $output .= '</div>';
    } else {
        $output = '<p>No image sections found.</p>';
    }
    return $output;
}
add_shortcode('image_sections', 'isp_display_image_sections');

// Enqueue Styles
function isp_enqueue_styles() {
    wp_enqueue_style('isp-styles', plugin_dir_url(__FILE__) . 'style.css');
}
add_action('wp_enqueue_scripts', 'isp_enqueue_styles');
