<?php
/*
Plugin Name: WP Coupon Display
Description: A plugin to display customizable coupon deals with redirection.
Version: 1.0
Author: Rahul K R
*/
function register_coupon_post_type() {
    register_post_type('coupon', array(
        'labels' => array(
            'name' => 'Coupons',
            'singular_name' => 'Coupon'
        ),
        'public' => true,
        'supports' => array('title', 'editor', 'thumbnail'),
    ));
}
add_action('init', 'register_coupon_post_type');
function add_coupon_meta_boxes() {
    add_meta_box('coupon_details', 'Coupon Details', 'render_coupon_meta_box', 'coupon', 'normal', 'high');
}
add_action('add_meta_boxes', 'add_coupon_meta_boxes');

function render_coupon_meta_box($post) {
    $before_price = get_post_meta($post->ID, '_before_price', true);
    $after_price = get_post_meta($post->ID, '_after_price', true);
    $deal_link = get_post_meta($post->ID, '_deal_link', true);

    echo '<label>Before Price:</label>';
    echo '<input type="text" name="before_price" value="' . esc_attr($before_price) . '">';
    echo '<label>After Price:</label>';
    echo '<input type="text" name="after_price" value="' . esc_attr($after_price) . '">';
    echo '<label>Deal Link:</label>';
    echo '<input type="url" name="deal_link" value="' . esc_attr($deal_link) . '">';
}

function save_coupon_meta($post_id) {
    if (array_key_exists('before_price', $_POST)) {
        update_post_meta($post_id, '_before_price', sanitize_text_field($_POST['before_price']));
    }
    if (array_key_exists('after_price', $_POST)) {
        update_post_meta($post_id, '_after_price', sanitize_text_field($_POST['after_price']));
    }
    if (array_key_exists('deal_link', $_POST)) {
        update_post_meta($post_id, '_deal_link', esc_url($_POST['deal_link']));
    }
}
add_action('save_post', 'save_coupon_meta');
function display_coupons_shortcode($atts) {
    $atts = shortcode_atts(array('items_per_row' => 3), $atts);
    $query = new WP_Query(array('post_type' => 'coupon'));

    ob_start();
    if ($query->have_posts()) {
        echo '<div class="coupon-grid" style="display: flex; flex-wrap: wrap;">';
        while ($query->have_posts()) {
            $query->the_post();
            $before_price = get_post_meta(get_the_ID(), '_before_price', true);
            $after_price = get_post_meta(get_the_ID(), '_after_price', true);
            $deal_link = get_post_meta(get_the_ID(), '_deal_link', true);

            echo '<div class="coupon-item" style="flex: 1 0 ' . (100 / $atts['items_per_row']) . '%; box-sizing: border-box; padding: 10px;">';
            echo '<a href="' . esc_url(get_permalink()) . '">';
            echo '<div class="coupon-content">';
            echo '<img src="' . get_the_post_thumbnail_url() . '" alt="' . get_the_title() . '">';
            echo '<h2>' . get_the_title() . '</h2>';
            echo '<p>Before: ' . esc_html($before_price) . '</p>';
            echo '<p>After: ' . esc_html($after_price) . '</p>';
            echo '<button>View Deal</button>';
            echo '</div>';
            echo '</a>';
            echo '</div>';
        }
        echo '</div>';
        wp_reset_postdata();
    }
    return ob_get_clean();
}
add_shortcode('display_coupons', 'display_coupons_shortcode');
