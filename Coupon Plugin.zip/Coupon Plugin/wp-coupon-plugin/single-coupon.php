<?php
// Check if this file is accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

get_header(); // Load the WordPress header.
?>

<div class="coupon-detail">
    <?php while (have_posts()) : the_post(); ?>
        <div class="coupon-container">
            <div class="coupon-image">
                <?php if (has_post_thumbnail()) : ?>
                    <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'full'); ?>" alt="<?php the_title(); ?>">
                <?php endif; ?>
            </div>
            <div class="coupon-info">
                <h1><?php the_title(); ?></h1>
                <p><?php the_content(); ?></p>
                <p><strong>Before Price:</strong> <?php echo esc_html(get_post_meta(get_the_ID(), '_before_price', true)); ?></p>
                <p><strong>After Price:</strong> <?php echo esc_html(get_post_meta(get_the_ID(), '_after_price', true)); ?></p>
                <a class="coupon-deal-button" href="<?php echo esc_url(get_post_meta(get_the_ID(), '_deal_link', true)); ?>" target="_blank">
                    Go to Deal
                </a>
            </div>
        </div>
    <?php endwhile; ?>
</div>

<?php get_footer(); // Load the WordPress footer. ?>
